//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FILEREV.rc
//
#define IDD_FILEREV                     1
#define IDC_FILESELECT                  101
#define IDI_FILEREV                     102
#define IDC_FILENAME                    1000
#define IDC_REVERSE                     1001
#define IDC_TEXTTYPE                    1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
