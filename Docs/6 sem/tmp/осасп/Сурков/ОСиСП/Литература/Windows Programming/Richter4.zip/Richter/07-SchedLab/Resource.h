//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SchedLab.rc
//
#define IDD_SCHEDLAB                    101
#define IDI_SCHEDLAB                    103
#define IDC_PROCESSPRIORITYCLASS        1015
#define IDC_THREADRELATIVEPRIORITY      1016
#define IDC_SLEEPTIME                   1017
#define IDC_SUSPEND                     1018
#define IDC_WORK                        1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
