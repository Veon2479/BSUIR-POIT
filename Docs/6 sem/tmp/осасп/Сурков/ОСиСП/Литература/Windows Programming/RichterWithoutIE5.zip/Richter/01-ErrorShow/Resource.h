//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ErrorShow.rc
//
#define IDD_ERRORSHOW                   101
#define IDI_ERRORSHOW                   102
#define IDC_ERRORCODE                   1000
#define IDC_ERRORTEXT                   1001
#define IDC_ALWAYSONTOP                 1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
