﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyLibrary
{
    public class MyClass
    {
        public string Concatinate(string s1, string s2, string s3)
        {
            return s1 + s2 + s3;
        }
    }
}
