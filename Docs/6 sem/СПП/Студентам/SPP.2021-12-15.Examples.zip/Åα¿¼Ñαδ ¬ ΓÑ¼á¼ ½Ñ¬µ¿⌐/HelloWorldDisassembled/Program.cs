﻿using System;

namespace HelloWorldDisassembled
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello!!!");
            Console.ReadLine();
        }
    }
}
