#include "Module1.h"
#include "Module2.h"

void main()
{
	MyIntArray a1;
	MyIntQueue q1;
}