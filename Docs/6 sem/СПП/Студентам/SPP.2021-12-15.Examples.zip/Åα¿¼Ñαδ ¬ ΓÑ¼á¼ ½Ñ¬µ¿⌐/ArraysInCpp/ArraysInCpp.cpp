// ArraysInCpp.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

int IntegerArray[] = { 1, 2, 3 };

int _tmain(int argc, _TCHAR* argv[])
{
    int *ArrayPtr = &IntegerArray[0];
	return 0;
}

