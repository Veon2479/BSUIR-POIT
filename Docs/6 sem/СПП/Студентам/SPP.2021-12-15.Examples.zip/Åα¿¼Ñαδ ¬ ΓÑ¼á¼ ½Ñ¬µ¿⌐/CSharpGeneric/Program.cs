﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSharpGeneric
{
    class Program
    {
        static void Main(string[] args)
        {
            MyList<object> array = new MyList<object>();
            
            List<object> list = new List<object>();
        }
    }
}
